export default function NoPage(){
    return(
        <>
        <h3><i><b>No Page found</b></i></h3>
        </>
    );
}